#!/bin/bash


echo Hello >> /tmp/hello
